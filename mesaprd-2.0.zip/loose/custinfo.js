function modifyTextField(field, bDisabled) {
	field.disabled = bDisabled
	if (bDisabled) {
		field.onfocus = function() {this.blur(); };	
	}
	else {
		field.onfocus = function() {};			
	}
}

function ConvertAllFields(bClearFormIfNecessary) {


  if (document.custinfoform.billtocopy.checked) {

    document.custinfoform.billtocopy.value = "1"
	document.custinfoform.txtsfirstname.value = document.custinfoform.txtfirstname.value
	document.custinfoform.txtslastname.value = document.custinfoform.txtlastname.value
	document.custinfoform.txtscompany.value = document.custinfoform.txtcompany.value
	document.custinfoform.txtsaddress1.value = document.custinfoform.txtaddress1.value
	document.custinfoform.txtsaddress2.value = document.custinfoform.txtaddress2.value
	document.custinfoform.txtscity.value = document.custinfoform.txtcity.value
	document.custinfoform.txtsstate.value = document.custinfoform.txtstate.value
	document.custinfoform.txtszipcode.value = document.custinfoform.txtzipcode.value
	document.custinfoform.shiptocountry.value = document.custinfoform.billtocountry.value
	document.custinfoform.txtsphone.value = document.custinfoform.txtphone.value
	document.custinfoform.txtsemail.value = document.custinfoform.txtemail.value

	EnableAllFields(true)
  }
  else if (bClearFormIfNecessary) {
	document.custinfoform.txtsfirstname.value = ""
	document.custinfoform.txtslastname.value = ""
	document.custinfoform.txtscompany.value = ""
	document.custinfoform.txtsaddress1.value = ""
	document.custinfoform.txtsaddress2.value = ""
	document.custinfoform.txtscity.value = ""
	document.custinfoform.txtszipcode.value = ""
	document.custinfoform.txtsstate.value=""
	document.custinfoform.txtsstate.selectedIndex = ""
	document.custinfoform.shiptocountry.selectedIndex = 247
	document.custinfoform.txtsphone.value = ""
	document.custinfoform.txtsemail.value = ""

	EnableAllFields(false)
  }
  
  var a = document.getElementById('GiftMsg');
	if (a.style.display =='') {
		a.style.display = 'none';
	}
	else {
		a.style.display='';
	}
}

function EnableAllFields(bDisabled) {
	modifyTextField(document.custinfoform.txtsfirstname, bDisabled)
	modifyTextField(document.custinfoform.txtslastname, bDisabled)
	modifyTextField(document.custinfoform.txtscompany, bDisabled)
	modifyTextField(document.custinfoform.txtsaddress1, bDisabled)
	modifyTextField(document.custinfoform.txtsaddress2, bDisabled)
	modifyTextField(document.custinfoform.txtscity, bDisabled)
	modifyTextField(document.custinfoform.txtsstate, bDisabled)
	modifyTextField(document.custinfoform.txtszipcode, bDisabled)
	modifyTextField(document.custinfoform.shiptocountry, bDisabled)
	modifyTextField(document.custinfoform.txtsphone, bDisabled)
	modifyTextField(document.custinfoform.txtsemail, bDisabled)
	modifyTextField(document.custinfoform.txtgiftmsg1, bDisabled)
	modifyTextField(document.custinfoform.txtgiftmsg2, bDisabled)
	modifyTextField(document.custinfoform.txtgiftmsg3, bDisabled)
	modifyTextField(document.custinfoform.txtgiftmsg4, bDisabled)
	modifyTextField(document.custinfoform.txtgiftmsg5, bDisabled)
	modifyTextField(document.custinfoform.txtgiftmsg6, bDisabled)

	if (bDisabled)
	{
		document.custinfoform.txtgiftmsg1.style.background='#E7E7E7'
		document.custinfoform.txtgiftmsg2.style.background='#E7E7E7'
		document.custinfoform.txtgiftmsg3.style.background='#E7E7E7'
		document.custinfoform.txtgiftmsg4.style.background='#E7E7E7'
		document.custinfoform.txtgiftmsg5.style.background='#E7E7E7'
		document.custinfoform.txtgiftmsg6.style.background='#E7E7E7'
	}
	else
	{
		
		document.custinfoform.txtgiftmsg1.style.background='#FFFFFF'
		document.custinfoform.txtgiftmsg2.style.background='#FFFFFF'
		document.custinfoform.txtgiftmsg3.style.background='#FFFFFF'
		document.custinfoform.txtgiftmsg4.style.background='#FFFFFF'
		document.custinfoform.txtgiftmsg5.style.background='#FFFFFF'
		document.custinfoform.txtgiftmsg6.style.background='#FFFFFF'		
	}
	return true
}

function getObject(obj) {
  var theObj;
  if(document.all) {
    if(typeof obj=="string") {
      return document.all(obj);
    } else {
      return obj.style;
    }
  }
  if(document.getElementById) {
    if(typeof obj=="string") {
      return document.getElementById(obj);
    } else {
      return obj.style;
    }
  }
  return null;
}

function Contchar(exittxt,texto) {
  var exittxtObj=getObject(exittxt);
  exittxtObj.innerHTML = texto ;
}

function validateForm(billtophonereq) {
	

  var haserror=false
 // var regex = /^(?:\([2-9]\d{2}\)\ ?|[2-9]\d{2}(?:\-?|\ ?))[2-9]\d{2}[- ]?\d{4}$/
 // var regex2 = /^(?:\([2-9]\d{2}\)\ ?|[2-9]\d{2}(?:\-?|\ ?))[2-9]\d{2}[- ]?\d{4}$/
 // var reqfield = "The following fields are required: "

	Contchar('bfname','')
	Contchar('blname','')
	Contchar('baddr1','')
	Contchar('bcity','')
	Contchar('bstate','')
	Contchar('bzip','')
	Contchar('bemail','')
	Contchar('bpwd','')
	
	if (custinfoform.chkboxbilltocopy.value == 1)
	{
	//if (custinfoform.billtocopy.value == 0)
	{	
	Contchar('sfname','')
	Contchar('slname','')
	Contchar('saddr1','')
	Contchar('scity','')
	Contchar('sstate','')
	Contchar('szip','')
	}
	}
	
// Begin Required Field Check
	
	if (custinfoform.txtfirstname.value == "")
	{
		Contchar('bfname','(Required)')
		haserror=true		
	}
	if (custinfoform.txtlastname.value == "")
	{
		Contchar('blname','(Required)')
		haserror=true		
	}
	if (custinfoform.txtaddress1.value == "" && custinfoform.txtaddress2.value == "")
	{
		Contchar('baddr1','(Required)')
		haserror=true		
	}
	if (custinfoform.txtcity.value == "")
	{
		Contchar('bcity','(Required)')
		haserror=true		
	}
	if (custinfoform.txtstate.value == "")
	{
		Contchar('bstate','(Required)')
		haserror=true		
	}
	if (custinfoform.txtzipcode.value == "")
	{
		Contchar('bzip','(Required)')
		haserror=true		
	}
	if (custinfoform.txtphone.value == "" && billtophonereq==1)
	{
		Contchar('bphone','(Required)')
		haserror=true		
	}
	if (custinfoform.txtemail.value == "")
	{
		Contchar('bemail','(Required)')		
		haserror=true
	}
	if (custinfoform.txtemail.value.length != 0 && !/^[a-zA-Z0-9._-]+@([a-zA-Z0-9.-]+\.)+[a-zA-Z0-9.-]{2,4}$/.test(custinfoform.txtemail.value))
	{
		Contchar('bemail','Invalid Email Address')		
		haserror=true
	}
	
		
	 if (custinfoform.registered.value==0)
	 {
		if (custinfoform.txtregpassword.value.length > 0)
		{		
			if (custinfoform.txtregpassword.value.length < 4)
			{
				Contchar('bpwd','\<br>(password must be at least 4 characters)')
				haserror=true
			}
			if (custinfoform.txtregpassword.value !== custinfoform.txtregpassword2.value)
			{
				Contchar('bpwd','\<br>(Your passwords do not match; please retype your password in both fields)')
				haserror=true
			}	
		}
	}
		

	if (custinfoform.billtocopy.value == 0)
	{
		if (custinfoform.txtsfirstname.value == "")
		{
			Contchar('sfname','(Required)')
			haserror=true		
		}
		if (custinfoform.txtslastname.value == "")
		{
			Contchar('slname','(Required)')
			haserror=true		
		}
		if (custinfoform.txtsaddress1.value == "" && custinfoform.txtsaddress2.value == "")
		{
			Contchar('saddr1','(Required)')
			haserror=true		
		}
		if (custinfoform.txtscity.value == "")
		{
			Contchar('scity','(Required)')
			haserror=true		
		}
		if (custinfoform.txtsstate.value == "")
		{
			Contchar('sstate','(Required)')
			haserror=true		
		}
		if (custinfoform.txtszipcode.value == "")
		{
			Contchar('szip','(Required)')
			haserror=true		
		}
		
	}
	
	
	//return false ;
	
	
	if (haserror)
		{
		window.location="custinfo.asp#billtab";
		return false ;
		}
	
	 return true ;
	 
}